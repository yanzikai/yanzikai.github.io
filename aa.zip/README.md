﻿# 第一次提交 11

## git 使用前准备
* node 环境
* git

#### 克隆 
> `$ git clone https://github.com/yanzikai/yanzikai.github.io.git`
#### 检查状态
> `$ git status `
#### 选择修改文件
> `$ git add .`
#### 将修改从暂存区提交到本地版本库 添加备注
> `$ git commit -m "描述信息"`
#### 将本地版本库推送到远程服务器
> `$ git push `

[主页链接](https://yanzikai.github.io '主页链接')

#### ---未完待续
